// ─── Add these keys to your existing translation files ───────────────────────
//
// src/renderer/i18n/locales/ru.json  →  add under "pos":
// src/renderer/i18n/locales/uz.json  →  add under "pos":

// ── ru.json additions ─────────────────────────────────────────────────────────
export const ruAdditions = {
  pos: {
    // ... your existing keys ...

    // Weight scale
    weightItem: "Весовой товар",
    weightScanned: "Отсканирован весовой товар",
    productNotFound: "Товар не найден (штрих-код: {{barcode}})",
    pluNotFound: "Товар с PLU {{plu}} не найден. Проверьте настройки товара.",
    zeroWeight: "Весы вернули нулевой вес — повторите взвешивание",
    invalidBarcode: "Неверный штрих-код — попробуйте снова",
    pricePerKg: "{{price}} / кг",
  },

  products: {
    // ... your existing keys ...

    // PLU field (shown in ProductForm.tsx for weight products)
    plu: "PLU (код для весов)",
    pluHelp: "Введите номер PLU, который будет запрограммирован на весах (1–99999)",
    isWeightProduct: "Весовой товар",
    isWeightProductHelp: "Включите для товаров, которые взвешиваются на весах",
  },
};

// ── uz.json additions ─────────────────────────────────────────────────────────
export const uzAdditions = {
  pos: {
    weightItem: "Og'irlikli mahsulot",
    weightScanned: "Og'irlikli mahsulot skanerlanadi",
    productNotFound: "Mahsulot topilmadi (shtrix-kod: {{barcode}})",
    pluNotFound: "PLU {{plu}} li mahsulot topilmadi. Mahsulot sozlamalarini tekshiring.",
    zeroWeight: "Tarozi nol og'irlik qaytardi — qayta o'lchang",
    invalidBarcode: "Noto'g'ri shtrix-kod — qayta urinib ko'ring",
    pricePerKg: "{{price}} / kg",
  },

  products: {
    plu: "PLU (tarozi kodi)",
    pluHelp: "Tarozida dasturlashtirilgan PLU raqamini kiriting (1–99999)",
    isWeightProduct: "Og'irlikli mahsulot",
    isWeightProductHelp: "Tarozida o'lchanadiganlar uchun yoqing",
  },
};

/*
─── Also add the `plu` field to your Product form (ProductForm.tsx) ───────────

When admin creates/edits a product that is sold by weight, they must set:
  - isWeightProduct: true
  - plu: <number matching the PLU programmed on the Rongta scale>

Example admin UI snippet:

<Form.Item label={t('products.isWeightProduct')}>
  <Switch
    checked={isWeightProduct}
    onChange={setIsWeightProduct}
  />
</Form.Item>

{isWeightProduct && (
  <Form.Item
    label={t('products.plu')}
    help={t('products.pluHelp')}
    rules={[{ required: true, min: 1, max: 99999 }]}
  >
    <InputNumber
      min={1}
      max={99999}
      value={plu}
      onChange={setPlu}
      placeholder="42"
    />
  </Form.Item>
)}

And in your Prisma schema, add to Product model:
  plu          Int?     @unique  // PLU code for scale items (1–99999)
  isWeightProduct Boolean @default(false) @map("is_weight_product")
*/
