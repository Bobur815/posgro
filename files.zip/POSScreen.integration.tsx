/**
 * POSScreen.tsx — updated to support Rongta RLS weight barcode scanning
 *
 * Key changes vs. your original POSScreen:
 * - handleScan() now routes weight barcodes vs regular barcodes
 * - Weight items show "1.250 kg" in the cart instead of just "1"
 * - WeightItemBadge component visually distinguishes weight items
 */

import React, { useRef, useCallback } from "react";
import { useTranslation } from "react-i18next";
import { useWeightBarcode, type WeightCartItem } from "../hooks/useWeightBarcode";

// ─── Types ────────────────────────────────────────────────────────────────────

interface CartItem {
  product: {
    id: number;
    nameRu: string;
    nameUz: string;
    price: number;
    barcode: string;
    plu?: string;
    unit: string;
  };
  quantity: number;
  unitPrice: number;
  subtotal: number;
  weightDisplay?: string;
  isWeightItem?: boolean;
}

// ─── Component ────────────────────────────────────────────────────────────────

export function POSScreen() {
  const { t, i18n } = useTranslation();
  const barcodeInputRef = useRef<HTMLInputElement>(null);

  // ── Your existing products store ──────────────────────────────────────────
  // Replace with your actual Zustand store selector
  const products: CartItem["product"][] = []; // useProductsStore(s => s.products)
  const cartItems: CartItem[] = []; // useCartStore(s => s.items)
  const addToCart = (_item: CartItem) => {}; // useCartStore(s => s.addItem)
  const showError = (_msg: string) => {}; // your toast/notification fn

  // ── PLU lookup function ───────────────────────────────────────────────────
  // Products need a `plu` field — set this when configuring products in admin
  const getProductByPlu = useCallback(
    (pluCode: string) => products.find((p) => p.plu === pluCode),
    [products]
  );

  // ── Weight barcode hook ───────────────────────────────────────────────────
  const { handleScan } = useWeightBarcode({ getProductByPlu });

  // ── Main barcode handler (called on Enter in the barcode input) ───────────
  const onBarcodeScanned = useCallback(
    (rawBarcode: string) => {
      const result = handleScan(rawBarcode);

      switch (result.type) {
        case "weight": {
          // Weight item from Rongta scale — add directly to cart
          const { item } = result;
          addToCart({
            product: item.product,
            quantity: item.quantity,          // e.g., 1.250 (kg)
            unitPrice: item.unitPrice,
            subtotal: item.subtotal,
            weightDisplay: item.weightDisplay, // e.g., "1.250 kg"
            isWeightItem: true,
          });
          break;
        }

        case "regular": {
          // Normal product barcode — your existing lookup flow
          const product = products.find((p) => p.barcode === result.barcode);
          if (product) {
            addToCart({
              product,
              quantity: 1,
              unitPrice: product.price,
              subtotal: product.price,
            });
          } else {
            showError(t("pos.productNotFound", { barcode: result.barcode }));
          }
          break;
        }

        case "error": {
          showError(result.message);
          break;
        }
      }

      // Clear and refocus the input for the next scan
      if (barcodeInputRef.current) {
        barcodeInputRef.current.value = "";
        barcodeInputRef.current.focus();
      }
    },
    [handleScan, products, addToCart, showError, t]
  );

  // ─────────────────────────────────────────────────────────────────────────
  return (
    <div className="pos-screen">
      {/* Barcode input — focused, invisible or visible depending on your UI */}
      <input
        ref={barcodeInputRef}
        type="text"
        autoFocus
        style={{ opacity: 0, position: "absolute" }} // hidden but focused
        onKeyDown={(e) => {
          if (e.key === "Enter") {
            onBarcodeScanned((e.target as HTMLInputElement).value);
          }
        }}
        placeholder={t("pos.scanBarcode")}
        aria-label="Barcode scanner input"
      />

      {/* Cart items */}
      <div className="cart">
        {cartItems.map((item, index) => (
          <CartRow key={index} item={item} />
        ))}
      </div>

      {/* ...rest of your POS UI */}
    </div>
  );
}

// ─── Cart Row Component ───────────────────────────────────────────────────────

function CartRow({ item }: { item: CartItem }) {
  const { i18n } = useTranslation();
  const lang = i18n.language;
  const productName =
    lang === "uz" ? item.product.nameUz : item.product.nameRu;

  return (
    <div className="cart-row">
      <span className="product-name">{productName}</span>

      {/* Show weight display for scale items, quantity for regular items */}
      <span className="quantity">
        {item.isWeightItem
          ? item.weightDisplay                    // "1.250 kg"
          : `${item.quantity} ${item.product.unit}` // "2 шт"
        }
      </span>

      {/* Price per unit */}
      <span className="unit-price">
        {formatCurrency(item.unitPrice)}
        {item.isWeightItem ? "/кг" : ""}
      </span>

      <span className="subtotal">{formatCurrency(item.subtotal)}</span>

      {/* Visual badge for weight items */}
      {item.isWeightItem && (
        <span className="weight-badge" title="Весовой товар">
          ⚖️
        </span>
      )}
    </div>
  );
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

function formatCurrency(amount: number): string {
  return new Intl.NumberFormat("uz-UZ").format(amount) + " сум";
}
