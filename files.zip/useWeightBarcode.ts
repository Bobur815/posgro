/**
 * useWeightBarcode Hook
 *
 * Handles the full flow when a cashier scans a label from the Rongta RLS scale:
 * 1. Detects if the barcode is a weight barcode
 * 2. Parses the PLU code and weight
 * 3. Looks up the product by its PLU field
 * 4. Returns a cart-ready item with the correct quantity (weight) and price
 */

import { useCallback } from "react";
import {
  isWeightBarcode,
  parseWeightBarcode,
  calculateWeightPrice,
  validateEan13CheckDigit,
  type WeightBarcodeConfig,
} from "../../shared/utils/weightBarcode";

// ─── Types ────────────────────────────────────────────────────────────────────

/** Matches your existing Product model from Prisma */
export interface Product {
  id: number;
  barcode: string;
  /** PLU code stored as a string like "00042" — set this when adding products */
  plu?: string;
  nameUz: string;
  nameRu: string;
  /** Price per unit (per kg for weight items, per piece for regular items) */
  price: number;
  stock: number;
  unit: string; // "кг", "г", "шт", "л", etc.
  categoryId: number;
  active: boolean;
}

export interface WeightCartItem {
  product: Product;
  /** Weight in kg (e.g., 1.250) */
  quantity: number;
  /** Price per kg */
  unitPrice: number;
  /** Total price = quantity × unitPrice */
  subtotal: number;
  /** Human-readable weight e.g. "1.250 kg" */
  weightDisplay: string;
  /** Indicates this item came from a weight barcode scan */
  isWeightItem: true;
}

export type ScanResult =
  | { type: "weight"; item: WeightCartItem }
  | { type: "regular"; barcode: string }
  | { type: "error"; message: string; code: ErrorCode };

export type ErrorCode =
  | "INVALID_CHECKSUM"
  | "PRODUCT_NOT_FOUND"
  | "ZERO_WEIGHT"
  | "PRODUCT_INACTIVE";

// ─── Hook ─────────────────────────────────────────────────────────────────────

interface UseWeightBarcodeOptions {
  /** Function to look up a product by its PLU code (e.g., "00042") */
  getProductByPlu: (pluCode: string) => Product | undefined;
  /** Override Rongta RLS defaults if needed */
  scaleConfig?: Partial<WeightBarcodeConfig>;
}

export function useWeightBarcode({
  getProductByPlu,
  scaleConfig,
}: UseWeightBarcodeOptions) {
  const config: WeightBarcodeConfig = {
    weightDecimalPlaces: 3,
    outputUnit: "kg",
    ...scaleConfig,
  };

  /**
   * Call this whenever a barcode is scanned.
   * Returns a ScanResult — check `result.type` to handle each case.
   *
   * @example
   * const result = handleScan("2012340012505");
   * if (result.type === "weight") {
   *   addToCart(result.item);
   * } else if (result.type === "regular") {
   *   lookupByBarcode(result.barcode);  // your existing flow
   * }
   */
  const handleScan = useCallback(
    (barcode: string): ScanResult => {
      const trimmed = barcode.trim();

      // ── Not a weight barcode → fall through to regular lookup ────────────
      if (!isWeightBarcode(trimmed)) {
        return { type: "regular", barcode: trimmed };
      }

      // ── Validate EAN-13 check digit ───────────────────────────────────────
      if (!validateEan13CheckDigit(trimmed)) {
        return {
          type: "error",
          message: "Barcode checksum invalid — try scanning again",
          code: "INVALID_CHECKSUM",
        };
      }

      // ── Parse weight and PLU ──────────────────────────────────────────────
      const parsed = parseWeightBarcode(trimmed, config);
      if (!parsed) {
        return {
          type: "error",
          message: "Could not parse weight barcode",
          code: "INVALID_CHECKSUM",
        };
      }

      if (parsed.weight <= 0) {
        return {
          type: "error",
          message: "Scale returned zero weight — please re-weigh the item",
          code: "ZERO_WEIGHT",
        };
      }

      // ── Look up product by PLU ────────────────────────────────────────────
      const product = getProductByPlu(parsed.pluCode);
      if (!product) {
        return {
          type: "error",
          message: `Product with PLU ${parsed.pluCode} not found. Make sure the PLU is set in the product settings.`,
          code: "PRODUCT_NOT_FOUND",
        };
      }

      if (!product.active) {
        return {
          type: "error",
          message: `Product "${product.nameRu}" is inactive`,
          code: "PRODUCT_INACTIVE",
        };
      }

      // ── Build cart item ───────────────────────────────────────────────────
      const subtotal = calculateWeightPrice(product.price, parsed.weight);

      const item: WeightCartItem = {
        product,
        quantity: parsed.weight,
        unitPrice: product.price,
        subtotal,
        weightDisplay: parsed.weightDisplay,
        isWeightItem: true,
      };

      return { type: "weight", item };
    },
    [getProductByPlu, config]
  );

  return { handleScan };
}
