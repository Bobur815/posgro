/**
 * Weight Barcode Parser for Rongta RLS Label Scale
 *
 * Rongta RLS scales print EAN-13 barcodes starting with "2".
 * The barcode encodes both the product PLU and the weight.
 *
 * Standard Format (EAN-13, 13 digits):
 * ┌───┬───────────┬───────────┬───┐
 * │ 2 │  P P P P P│  W W W W W│ C │
 * └───┴───────────┴───────────┴───┘
 *   0    1 2 3 4 5   6 7 8 9 10  11  (but EAN-13 is 13 digits including check)
 *
 * Actually EAN-13 layout:
 * Position:  0   1 2 3 4 5   6 7 8 9 10 11   12
 * Content:  [2] [P P P P P] [W W W W W  W] [CHK]
 *
 * D0      = "2" (weight item flag)
 * D1–D5   = PLU code (5 digits, zero-padded)  → "01234"
 * D6–D11  = Weight value (6 digits)            → "001250" = 1250g = 1.250 kg
 * D12     = EAN-13 check digit (auto)
 *
 * Some scales use 5-digit weight field:
 * D0      = "2"
 * D1–D5   = PLU (5 digits)
 * D6–D10  = Weight (5 digits)  → "01250" = 1250g
 * D11     = "0" padding
 * D12     = check digit
 *
 * Configure WEIGHT_DECIMAL_PLACES to match your scale's setting.
 */

export type WeightUnit = "kg" | "g";

export interface WeightBarcodeConfig {
  /**
   * How many decimal places the scale uses in the weight field.
   * - 3 = grams precision (001250 → 1.250 kg)   ← Rongta RLS default
   * - 2 = 10-gram precision (00125 → 1.25 kg)
   */
  weightDecimalPlaces: 2 | 3;

  /** Output unit for the parsed weight */
  outputUnit: WeightUnit;
}

export interface ParsedWeightBarcode {
  /** The raw 13-digit barcode string */
  raw: string;

  /** PLU code to look up in your products table */
  pluCode: string;

  /** Numeric PLU (without leading zeros) */
  pluNumber: number;

  /** Weight in the configured output unit */
  weight: number;

  /** Weight unit (kg or g) */
  unit: WeightUnit;

  /** Human-readable weight string e.g. "1.250 kg" */
  weightDisplay: string;
}

const DEFAULT_CONFIG: WeightBarcodeConfig = {
  weightDecimalPlaces: 3, // Rongta RLS default: grams with 3 decimal places in kg
  outputUnit: "kg",
};

/**
 * Returns true if the scanned barcode is a weight barcode from a label scale.
 * Weight barcodes always start with "2" and are exactly 13 digits long.
 */
export function isWeightBarcode(barcode: string): boolean {
  return (
    typeof barcode === "string" &&
    barcode.length === 13 &&
    barcode.startsWith("2") &&
    /^\d{13}$/.test(barcode)
  );
}

/**
 * Parses an EAN-13 weight barcode printed by a Rongta RLS (or compatible) scale.
 *
 * @param barcode - The 13-digit scanned barcode string
 * @param config  - Optional config (defaults match Rongta RLS factory settings)
 * @returns ParsedWeightBarcode or null if the barcode is not a valid weight barcode
 *
 * @example
 * const result = parseWeightBarcode("2012340012505");
 * // result.pluCode    → "01234"
 * // result.pluNumber  → 1234
 * // result.weight     → 1.250
 * // result.unit       → "kg"
 * // result.weightDisplay → "1.250 kg"
 */
export function parseWeightBarcode(
  barcode: string,
  config: WeightBarcodeConfig = DEFAULT_CONFIG
): ParsedWeightBarcode | null {
  if (!isWeightBarcode(barcode)) return null;

  // D0 = "2", D1–D5 = PLU (5 chars), D6–D11 = weight (6 chars), D12 = check
  const pluCode = barcode.substring(1, 6); // "01234"
  const weightRaw = barcode.substring(6, 12); // "001250"

  const pluNumber = parseInt(pluCode, 10);
  const weightInt = parseInt(weightRaw, 10);

  if (isNaN(pluNumber) || isNaN(weightInt)) return null;

  // Convert weight integer to actual value
  // e.g., 001250 with 3 decimal places → 1250 / 1000 = 1.250 kg
  const divisor = Math.pow(10, config.weightDecimalPlaces);
  let weight = weightInt / divisor;

  // Convert to output unit if needed
  if (config.outputUnit === "g") {
    weight = weight * 1000; // kg → g
  }

  const weightDisplay =
    config.outputUnit === "kg"
      ? `${weight.toFixed(config.weightDecimalPlaces)} kg`
      : `${Math.round(weight)} g`;

  return {
    raw: barcode,
    pluCode,
    pluNumber,
    weight,
    unit: config.outputUnit,
    weightDisplay,
  };
}

/**
 * Calculates the price for a weight-based item.
 *
 * @param pricePerKg - Product's price per kilogram
 * @param weightKg   - Scanned weight in kilograms
 * @returns Total price, rounded to 2 decimal places
 *
 * @example
 * calculateWeightPrice(12500, 1.250) → 15625  (UZS)
 */
export function calculateWeightPrice(
  pricePerKg: number,
  weightKg: number
): number {
  return Math.round(pricePerKg * weightKg * 100) / 100;
}

/**
 * Validates the EAN-13 check digit of a barcode.
 * Useful for catching scanner read errors.
 */
export function validateEan13CheckDigit(barcode: string): boolean {
  if (barcode.length !== 13 || !/^\d{13}$/.test(barcode)) return false;

  const digits = barcode.split("").map(Number);
  const checkDigit = digits[12];

  const sum = digits.slice(0, 12).reduce((acc, digit, index) => {
    return acc + digit * (index % 2 === 0 ? 1 : 3);
  }, 0);

  const calculated = (10 - (sum % 10)) % 10;
  return calculated === checkDigit;
}

/**
 * Formats a PLU number into a 5-digit zero-padded string
 * matching how products should be stored in your database.
 *
 * @example
 * formatPlu(42) → "00042"
 */
export function formatPlu(plu: number): string {
  return String(plu).padStart(5, "0");
}
